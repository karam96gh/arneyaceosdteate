const  pool = require('../config/db');
const { v4: uuidv4 } = require('uuid');

// جلب كل المباني
exports.getBuildings = (req, res) => {
     pool.promise().query('SELECT * FROM buildings')
        .then(([rows]) => res.json(rows))
        .catch(err => res.status(500).json({ error: err.message }));
};

// جلب مبنى معين مع العناصر الخاصة به
exports.getBuildingById = (req, res) => {
    const { id } = req.params;
     pool.promise().query('SELECT * FROM buildings WHERE id = ?', [id])
        .then(([building]) => {
            if (!building.length) return res.status(404).json({ message: 'Building not found' });

             pool.promise().query('SELECT * FROM building_items WHERE building_id = ?', [id])
                .then(([items]) => res.json({ ...building[0], items }))
                .catch(err => res.status(500).json({ error: err.message }));
        })
        .catch(err => res.status(500).json({ error: err.message }));
};

// إنشاء مبنى جديد
exports.createBuilding = (req, res) => {
    const { title, status } = req.body;
    const id = uuidv4();
     pool.promise().query('INSERT INTO buildings (id, title, status) VALUES (?, ?, ?)', [id, title, status])
        .then(() => res.json({ id, title, status }))
        .catch(err => res.status(500).json({ error: err.message }));
};

// تحديث مبنى
exports.updateBuilding = (req, res) => {
    const { id } = req.params;
    const { title, status } = req.body;
     pool.promise().query('UPDATE buildings SET title = ?, status = ? WHERE id = ?', [title, status, id])
        .then(() => res.json({ message: 'Building updated' }))
        .catch(err => res.status(500).json({ error: err.message }));
};

// حذف مبنى
exports.deleteBuilding = (req, res) => {
    const { id } = req.params;
     pool.promise().query('DELETE FROM buildings WHERE id = ?', [id])
        .then(() => res.json({ message: 'Building deleted' }))
        .catch(err => res.status(500).json({ error: err.message }));
};
